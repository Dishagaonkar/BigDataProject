from __future__ import annotations

from .engine import SimpleSearchEngine

__all__ = ["SimpleSearchEngine"]
