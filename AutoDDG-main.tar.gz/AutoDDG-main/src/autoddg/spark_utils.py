"""Utilities for Spark integration."""

def merge_spark_metadata_with_datamart(
    spark_metadata: dict,
    datamart_sample_metadata: dict
) -> dict:
    """
    Merge Spark-computed stats with datamart profiler format.
    Useful for hybrid approaches.
    """
    merged = spark_metadata.copy()
    
    # Enhance with datamart's semantic type detection
    # which is more sophisticated
    for col in merged['columns']:
        matching_col = next(
            (c for c in datamart_sample_metadata.get('columns', [])
             if c['name'] == col['name']),
            None
        )
        if matching_col:
            col['semantic_types'] = matching_col.get('semantic_types', [])
    
    return merged

def sample_large_dataset_for_semantic_profiling(
    spark_df,
    sample_size: int = 10000
) -> pd.DataFrame:
    """
    Sample large Spark DataFrame for detailed semantic profiling.
    
    Spark handles statistical profiling, but semantic type detection
    (from datamart_profiler) works best on pandas with full data.
    This samples strategically.
    """
    # Stratified sampling if possible
    total_count = spark_df.count()
    
    if total_count <= sample_size:
        return spark_df.toPandas()
    
    fraction = sample_size / total_count
    sample_df = spark_df.sample(withReplacement=False, fraction=fraction)
    
    return sample_df.toPandas()