from __future__ import annotations

from .generator import DatasetTopicGenerator

__all__ = ["DatasetTopicGenerator"]
