from __future__ import annotations

from typing import Tuple, Any

from beartype import beartype
from pandas import DataFrame as PandasDataFrame

# Allow Spark Types for type hinting and check availability
try:
    from pyspark.sql import DataFrame as SparkDataFrame
    HAS_SPARK = True
except ImportError:
    SparkDataFrame = Any
    HAS_SPARK = False


@beartype
def get_sample(
    data_pd: PandasDataFrame | SparkDataFrame, 
    sample_size: int, 
    random_state: int = 9
) -> Tuple[PandasDataFrame, str]:
    """
    Return a random sample or whole frame and its CSV text.
    Supports both Pandas and Spark DataFrames.

    Args:
        data_pd: Input DataFrame (Pandas or Spark)
        sample_size: Number of rows to sample
        random_state: Seed for reproducibility

    Returns:
        (sample_df, sample_csv) -> Returns a Pandas DataFrame and the CSV string
    """
    
    # Handle Spark DataFrames
    if HAS_SPARK and isinstance(data_pd, SparkDataFrame):
        # For Spark, we limit first to avoid pulling too much data
        # Note: sampling in Spark is expensive, so we often take head/limit 
        # for prompt generation unless strict random sampling is required.
        # Here we use limit for efficiency on big data.
        data_sample = data_pd.limit(sample_size).toPandas()
        sample_csv = data_sample.to_csv(index=False)
        return data_sample, sample_csv

    # Handle Pandas DataFrames (Existing Logic)
    if sample_size <= len(data_pd):
        data_sample = data_pd.sample(sample_size, random_state=random_state)
    else:
        data_sample = data_pd
        
    sample_csv = data_sample.to_csv(index=False)
    return data_sample, sample_csv