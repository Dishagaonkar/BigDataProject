from __future__ import annotations

from typing import Any, Tuple

from beartype import beartype
from pandas import DataFrame as PandasDataFrame

# Allow Spark Types for type hinting
try:
    from pyspark.sql import DataFrame as SparkDataFrame
except ImportError:
    SparkDataFrame = Any

from .description import DatasetDescriptionGenerator, SearchFocusedDescription
from .evaluation import BaseEvaluator
from .profiling import SemanticProfiler, profile_dataset
from .topic import DatasetTopicGenerator


@beartype
class AutoDDG:
    """AutoDDG - Automated Dataset Description Generator
    ... (docstring omitted for brevity) ...
    """

    def __init__(
        self,
        client: Any,
        model_name: str,
        *,
        description_temperature: float = 0.0,
        description_words: int = 100,
        search_model_name: str | None = None,
        semantic_model_name: str | None = None,
        topic_temperature: float = 0.0,
        evaluator: BaseEvaluator | None = None,
    ) -> None:
        self.client = client
        self.model_name = model_name
        self.description_generator = DatasetDescriptionGenerator(
            client=client,
            model_name=model_name,
            temperature=description_temperature,
            description_words=description_words,
        )
        self.semantic_profiler = SemanticProfiler(
            client=client,
            model_name=semantic_model_name or model_name,
        )
        self.topic_generator = DatasetTopicGenerator(
            client=client,
            model_name=model_name,
            temperature=topic_temperature,
        )
        self.search_description = SearchFocusedDescription(
            client=client,
            model_name=search_model_name or model_name,
        )
        self.evaluator = evaluator

    def describe_dataset(
        self,
        dataset_sample: str,
        dataset_profile: str | None = None,
        use_profile: bool = False,
        semantic_profile: str | None = None,
        use_semantic_profile: bool = False,
        data_topic: str | None = None,
        use_topic: bool = False,
    ) -> Tuple[str, str]:
        """
        Produce a short description from a CSV sample with optional context
        """
        return self.description_generator.generate_description(
            dataset_sample=dataset_sample,
            dataset_profile=dataset_profile,
            use_profile=use_profile,
            semantic_profile=semantic_profile,
            use_semantic_profile=use_semantic_profile,
            data_topic=data_topic,
            use_topic=use_topic,
        )

    def profile_dataframe(self, dataframe: PandasDataFrame | SparkDataFrame) -> Tuple[str, str]:
        """
        Summarise structure and coverage using the datamart profiler (Pandas)
        or native Spark aggregations (Spark).
        
        Args:
            dataframe: Input frame (Pandas or Spark)

        Returns:
            (profile_text, semantic_notes)
        """
        # The logic is handled inside profile_dataset in summary.py
        return profile_dataset(dataframe)

    def analyze_semantics(self, dataframe: PandasDataFrame | SparkDataFrame) -> str:
        """
        Infer column semantics with an LLM and return a short overview.
        
        If a Spark DataFrame is provided, a small sample is converted to Pandas
        locally for LLM analysis.

        Args:
            dataframe: Input frame

        Returns:
            Summary of column semantics
        """
        # Prepare dataframe for semantic profiler (needs Pandas)
        if hasattr(dataframe, "limit") and hasattr(dataframe, "toPandas"):
            # It is likely a Spark DataFrame
            # We only need a small sample for semantic inference
            df_to_process = dataframe.limit(10).toPandas()
        else:
            df_to_process = dataframe

        return self.semantic_profiler.analyze_dataframe(df_to_process)

    def generate_topic(
        self, title: str, original_description: str | None, dataset_sample: str
    ) -> str:
        """
        Generate a 2–3 word topic from title description and sample
        """
        return self.topic_generator.generate_topic(title, original_description, dataset_sample)

    def expand_description_for_search(self, description: str, topic: str) -> Tuple[str, str]:
        """
        Expand a readable description into a search-oriented variant
        """
        return self.search_description.expand_description(description, topic)

    def evaluate_description(self, description: str) -> str:
        """
        Score a description with the configured evaluator
        """
        if self.evaluator is None:
            raise RuntimeError(
                "No evaluator configured for AutoDDG. Provide one via set_evaluator()."
            )
        return self.evaluator.evaluate(description)

    def set_evaluator(self, evaluator: BaseEvaluator) -> None:
        """
        Attach or replace the evaluator to use for scoring
        """