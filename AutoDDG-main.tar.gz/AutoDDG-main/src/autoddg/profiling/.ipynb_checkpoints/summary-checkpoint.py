from __future__ import annotations

from datetime import datetime
from typing import List, Tuple, Any

import datamart_profiler
from beartype import beartype
from pandas import DataFrame as PandasDataFrame

# Try importing PySpark, handle case where it's not installed
try:
    from pyspark.sql import DataFrame as SparkDataFrame
    from pyspark.sql import functions as F
    HAS_SPARK = True
except ImportError:
    SparkDataFrame = Any
    HAS_SPARK = False


def _profile_spark(df: SparkDataFrame) -> Tuple[str, str]:
    """
    Generate profile using Spark for big datasets.
    Mimics the text output of datamart_profiler.
    """
    profile_summary: List[str] = []
    semantic_summary: List[str] = []

    # 1. Inspect Schema (Structural Types)
    dtypes = dict(df.dtypes)
    
    # 2. compute Aggregations (Min, Max, Distinct) in one pass for performance
    # We construct a list of aggregation expressions
    exprs = []
    numeric_types = ['int', 'bigint', 'float', 'double', 'decimal', 'long']
    timestamp_types = ['timestamp', 'date']
    
    cols_to_profile = df.columns
    
    for col_name in cols_to_profile:
        # === FIX: Escape column names with backticks to handle dots/spaces ===
        escaped_col = f"`{col_name}`"

        # Count distinct
        exprs.append(F.count_distinct(F.col(escaped_col)).alias(f"{col_name}_distinct"))
        
        # Min/Max for numeric or time types
        col_type = dtypes[col_name]
        is_profileable = any(t in col_type for t in numeric_types + timestamp_types)
        
        if is_profileable:
            exprs.append(F.min(F.col(escaped_col)).alias(f"{col_name}_min"))
            exprs.append(F.max(F.col(escaped_col)).alias(f"{col_name}_max"))

    # Execute aggregation
    stats = df.agg(*exprs).collect()[0]

    # 3. Generate Text
    for col_name in cols_to_profile:
        col_type = dtypes[col_name]
        column_summary = f"**{col_name}**: "
        column_summary += f"Data is of type {col_type}. "
        
        # Distincts
        # Note: Accessing the row by string key handles the dots correctly
        distinct_count = stats[f"{col_name}_distinct"]
        column_summary += f"There are {distinct_count} unique values. "
        
        # Coverage (Min/Max)
        if any(t in col_type for t in numeric_types):
            min_val = stats[f"{col_name}_min"]
            max_val = stats[f"{col_name}_max"]
            if min_val is not None and max_val is not None:
                column_summary += f"Coverage spans from {min_val} to {max_val}. "
        
        profile_summary.append(column_summary)

        # Temporal Coverage (Simple Heuristic based on type)
        if any(t in col_type for t in timestamp_types):
            min_val = stats[f"{col_name}_min"]
            max_val = stats[f"{col_name}_max"]
            if min_val and max_val:
                min_str = str(min_val)
                max_str = str(max_val)
                semantic_summary.append(
                    f"**Temporal coverage** for column {col_name}, covering from {min_str} to {max_str}."
                )

    final_profile_summary = (
        "The key data profile information for this dataset includes:\n" + "\n".join(profile_summary)
    )
    final_semantic_summary = "\n".join(semantic_summary)
    
    return final_profile_summary, final_semantic_summary


@beartype
def profile_dataset(data_frame: PandasDataFrame | SparkDataFrame) -> Tuple[str, str]:
    """
    Run profiling. Uses datamart_profiler for Pandas (small data) 
    and native Spark aggregations for Spark DataFrames (big data).

    Args:
        data_frame: Input frame (Pandas or Spark)

    Returns:
        (profile_text, semantic_notes)
    """
    
    # Check if input is a Spark DataFrame
    if HAS_SPARK and isinstance(data_frame, SparkDataFrame):
        return _profile_spark(data_frame)

    # Fallback to existing logic for Pandas
    metadata = datamart_profiler.process_dataset(data_frame)
    profile_summary: List[str] = []

    for column_meta in metadata.get("columns", []):
        column_summary = f"**{column_meta['name']}**: "

        structural_type = column_meta.get("structural_type", "Unknown")
        column_summary += f"Data is of type {structural_type.split('/')[-1].lower()}. "

        if "num_distinct_values" in column_meta:
            num_distinct_values = column_meta["num_distinct_values"]
            column_summary += f"There are {num_distinct_values} unique values. "

        if "coverage" in column_meta:
            low = 0
            high = 0
            for coverage in column_meta["coverage"]:
                lower_bound = coverage["range"].get("gte", low)
                upper_bound = coverage["range"].get("lte", high)
                low = min(low, lower_bound)
                high = max(high, upper_bound)
            column_summary += f"Coverage spans from {low} to {high}. "

        profile_summary.append(column_summary)

    final_profile_summary = (
        "The key data profile information for this dataset includes:\n" + "\n".join(profile_summary)
    )

    semantic_summary: List[str] = []
    if "temporal_coverage" in metadata:
        for temp_cov in metadata["temporal_coverage"]:
            column_names = ", ".join(temp_cov.get("column_names", []))
            temporal_resolution = temp_cov.get("temporal_resolution", "unknown")
            range_values = [
                entry["range"].get("gte")
                for entry in temp_cov.get("ranges", [])
                if entry.get("range")
            ] + [
                entry["range"].get("lte")
                for entry in temp_cov.get("ranges", [])
                if entry.get("range")
            ]
            range_values = [value for value in range_values if value is not None]
            if range_values:
                min_value = datetime.fromtimestamp(min(range_values)).strftime("%Y-%m-%d")
                max_value = datetime.fromtimestamp(max(range_values)).strftime("%Y-%m-%d")
                date_range = f"from {min_value} to {max_value}"
                semantic_summary.append(
                    f"**Temporal coverage** for columns {column_names} with resolution "
                    f"{temporal_resolution}, covering {date_range}."
                )

    if "spatial_coverage" in metadata:
        for spatial_cov in metadata["spatial_coverage"]:
            column_names = ", ".join(spatial_cov.get("column_names", []))
            spatial_resolution = spatial_cov.get("type", "unknown")
            semantic_summary.append(
                f"**Spatial coverage** for columns {column_names}, with type {spatial_resolution}."
            )

    final_semantic_summary = "\n".join(semantic_summary)
    return final_profile_summary, final_semantic_summary