from typing import Optional, Dict, Any
import pandas as pd

class SparkDataProfiler:
    """
    Wrapper for datamart_profiler that supports both local and Spark execution.
    """
    
    def __init__(
        self,
        use_spark: bool = False,
        spark_session: Optional['SparkSession'] = None,
        size_threshold_mb: float = 100.0
    ):
        """
        Args:
            use_spark: Force Spark usage
            spark_session: Existing Spark session or create new one
            size_threshold_mb: Auto-switch to Spark above this size
        """
        self.use_spark = use_spark
        self.size_threshold_mb = size_threshold_mb
        self._spark = spark_session
        
    @property
    def spark(self):
        """Lazy initialize Spark session."""
        if self._spark is None and self.use_spark:
            from pyspark.sql import SparkSession
            self._spark = SparkSession.builder \
                .appName("AutoDDG-Profiler") \
                .config("spark.driver.memory", "4g") \
                .getOrCreate()
        return self._spark
    
    def should_use_spark(self, data) -> bool:
        """Determine if Spark should be used based on data size."""
        if self.use_spark:
            return True
            
        # Estimate size for auto-detection
        if isinstance(data, str):  # file path
            import os
            size_mb = os.path.getsize(data) / (1024 * 1024)
            return size_mb > self.size_threshold_mb
        elif isinstance(data, pd.DataFrame):
            size_mb = data.memory_usage(deep=True).sum() / (1024 * 1024)
            return size_mb > self.size_threshold_mb
            
        return False
    
    def profile_with_spark(self, data_path: str, **kwargs) -> Dict[str, Any]:
        """
        Profile dataset using Spark for distributed processing.
        Returns metadata compatible with datamart_profiler format.
        """
        df = self.spark.read.csv(
            data_path, 
            header=True, 
            inferSchema=True
        )
        
        # Compute statistics using Spark
        metadata = {
            'size': df.count(),
            'nb_rows': df.count(),
            'columns': [],
            'materialize': {'identifier': data_path}
        }
        
        # Profile each column using Spark's distributed capabilities
        for col_name in df.columns:
            col_stats = self._profile_column_spark(df, col_name)
            metadata['columns'].append(col_stats)
        
        return metadata
    
    def _profile_column_spark(self, df, col_name: str) -> Dict[str, Any]:
        """Profile a single column using Spark operations."""
        from pyspark.sql import functions as F
        
        col_df = df.select(col_name)
        
        # Basic statistics
        stats = col_df.describe().toPandas()
        
        # Additional profiling
        col_metadata = {
            'name': col_name,
            'structural_type': str(df.schema[col_name].dataType),
            'num_distinct_values': col_df.distinct().count(),
        }
        
        # Type-specific statistics
        if df.schema[col_name].dataType.typeName() in ['int', 'long', 'double', 'float']:
            # Numerical column
            agg_result = col_df.agg(
                F.mean(col_name).alias('mean'),
                F.stddev(col_name).alias('stddev'),
                F.min(col_name).alias('min'),
                F.max(col_name).alias('max'),
                F.count(F.when(F.col(col_name).isNull(), 1)).alias('missing')
            ).first()
            
            col_metadata.update({
                'semantic_types': ['http://schema.org/Float'],
                'mean': float(agg_result['mean']) if agg_result['mean'] else None,
                'stddev': float(agg_result['stddev']) if agg_result['stddev'] else None,
                'coverage': (df.count() - agg_result['missing']) / df.count()
            })
        else:
            # Categorical column - sample top values
            top_values = col_df.groupBy(col_name) \
                .count() \
                .orderBy(F.desc('count')) \
                .limit(10) \
                .collect()
            
            col_metadata.update({
                'semantic_types': ['http://schema.org/Text'],
                'sample_values': [row[col_name] for row in top_values[:5]]
            })
        
        return col_metadata
    
    def profile_with_pandas(self, data, **kwargs) -> Dict[str, Any]:
        """Profile using standard datamart_profiler (pandas-based)."""
        import datamart_profiler
        return datamart_profiler.process_dataset(data, **kwargs)
    
    def profile_dataset(self, data, **kwargs) -> Dict[str, Any]:
        """
        Main profiling entry point - automatically selects Spark or pandas.
        """
        if self.should_use_spark(data):
            print(f"Using Spark for profiling large dataset")
            if isinstance(data, str):
                return self.profile_with_spark(data, **kwargs)
            else:
                # Save to temp file for Spark processing
                import tempfile
                with tempfile.NamedTemporaryFile(suffix='.csv', delete=False) as tmp:
                    if isinstance(data, pd.DataFrame):
                        data.to_csv(tmp.name, index=False)
                    return self.profile_with_spark(tmp.name, **kwargs)
        else:
            print(f"Using pandas for profiling small dataset")
            return self.profile_with_pandas(data, **kwargs)
